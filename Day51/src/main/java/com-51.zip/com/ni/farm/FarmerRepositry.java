package com.ni.farm;

import java.util.ArrayList;
import java.util.List;

public class FarmerRepositry {
    public static List<Farmer> farmerList = new ArrayList<>();
    
}
